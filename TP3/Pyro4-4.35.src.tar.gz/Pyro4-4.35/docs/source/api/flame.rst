:mod:`Pyro4.utils.flame` --- Foreign Location Automatic Module Exposer
======================================================================

.. automodule:: Pyro4.utils.flame
   :members:
