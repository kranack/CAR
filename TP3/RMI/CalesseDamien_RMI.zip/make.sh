#!/bin/sh

python -B launch.py
