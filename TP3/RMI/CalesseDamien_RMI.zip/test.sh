#!/bin/sh

python -B -m unittest discover -s test -p 'Test*.py'
